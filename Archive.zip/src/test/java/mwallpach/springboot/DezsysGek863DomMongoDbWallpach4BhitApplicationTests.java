package mwallpach.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DezsysGek863DomMongoDbWallpach4BhitApplicationTests {

	@Test
	void contextLoads() {
	}

}
